import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

def Message processData(Message message) {

    // Get incoming XML body
    def body = message.getBody(String)
    def root = new XmlSlurper().parseText(body)

    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)

    xml.root {
    metadata {
        fieldname(datatype: "VARCHAR", "CustomerID")
        fieldname(datatype: "VARCHAR", "CompanyName")
        fieldname(datatype: "VARCHAR", "ContactName")
        fieldname(datatype: "VARCHAR", "ContactTitle")
        fieldname(datatype: "VARCHAR", "Address")
        fieldname(datatype: "VARCHAR", "City")
        fieldname(datatype: "VARCHAR", "Region")
        fieldname(datatype: "VARCHAR", "PostalCode")
        fieldname(datatype: "VARCHAR", "Country")
        fieldname(datatype: "VARCHAR", "Phone")
        fieldname(datatype: "VARCHAR", "Fax")
    }
    // Loop through all Customer nodes
    root.'Customer'.each { cust ->
        row {
            CustomerID(cust.CustomerID.text())
            CompanyName(cust.CompanyName.text())
            ContactName(cust.ContactName.text())
            ContactTitle(cust.ContactTitle.text())
            Address(cust.Address.text())
            City(cust.City.text())
            Region(cust.Region.text())
            PostalCode(cust.PostalCode.text())
            Country(cust.Country.text())
            Phone(cust.Phone.text())
            Fax(cust.Fax.text())
        }
    }
}


    // Set transformed XML as new body
    message.setBody(writer.toString())
    return message
}
